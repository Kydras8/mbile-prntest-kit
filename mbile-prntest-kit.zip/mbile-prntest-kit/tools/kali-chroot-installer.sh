#!/data/data/com.termux/files/usr/bin/bash

echo "[+] Setting up Kali Linux via proot-distro..."

pkg install proot-distro -y

echo "[+] Installing Kali Linux chroot..."
proot-distro install kali

echo "[+] Kali Linux installed!"
echo "[+] To start Kali session, use:"
echo "proot-distro login kali"

echo "[+] Inside Kali you can run tools like:"
echo "apt update && apt install metasploit-framework nmap hydra sqlmap"
