#!/data/data/com.termux/files/usr/bin/bash

echo "[+] Installing Hydra brute force tool..."

pkg install git make autoconf bison coreutils clang binutils -y

cd ~
git clone https://github.com/vanhauser-thc/thc-hydra.git
cd thc-hydra || { echo "[-] Clone failed"; exit 1; }

echo "[+] Compiling Hydra (this can take a few minutes)..."
./configure && make -j$(nproc)

if [ $? -ne 0 ]; then
    echo "[-] Hydra compile failed."
    exit 1
fi

echo "[+] Moving Hydra binaries to Termux PATH..."
mkdir -p $PREFIX/bin
strip hydra pw-inspector || echo "[!] Strip failed (safe to ignore)"
cp hydra pw-inspector $PREFIX/bin/

echo "[+] Hydra installed. Test with: hydra -h"

# Clean up
cd ~ && rm -rf thc-hydra
