#!/data/data/com.termux/files/usr/bin/bash

echo "============================="
echo "   Kydras God Mode Setup"
echo "============================="

echo "[+] Updating Termux packages..."
pkg update -y && pkg upgrade -y

echo "[+] Installing core packages..."
pkg install git python nmap tsu curl wget nano zip proot-distro -y

echo "[+] Setting up tools directory..."
mkdir -p ~/mbile-prntest-kit/tools

echo "[+] Installing core tools via scripts..."
bash ~/mbile-prntest-kit/tools/hydra-install.sh
bash ~/mbile-prntest-kit/tools/sqlmap-setup.sh
bash ~/mbile-prntest-kit/tools/osint-pack.sh

echo "[+] Setup complete. Launch with: pentest-menu"
