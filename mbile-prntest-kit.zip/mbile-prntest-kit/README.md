# Kydras God Mode — Mobile Pentesting Toolkit

Welcome to **Kydras God Mode Mobile Toolkit** — built for **rooted Android (Pixel 7a)** using **GrapheneOS + Termux**.

---

## ✅ Quick Start
```bash
git clone git@github.com:kylerasmussen17771/mbile-prntest-kit.git
cd mbile-prntest-kit
bash setup.sh
pentest-menu
