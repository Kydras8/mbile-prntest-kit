#!/data/data/com.termux/files/usr/bin/bash

echo "[+] Installing OSINT tools (ReconDog, XSStrike, Sherlock)..."

pkg install git python -y
pip install --upgrade pip

# Install ReconDog
cd ~
git clone https://github.com/s0md3v/ReconDog.git

# Install XSStrike
git clone https://github.com/s0md3v/XSStrike.git
cd XSStrike && pip install -r requirements.txt && cd ~

# Install Sherlock
git clone https://github.com/sherlock-project/sherlock.git
cd sherlock && pip install -r requirements.txt && cd ~

echo "[+] OSINT pack installed:"
echo " - ReconDog: cd ~/ReconDog && python dog"
echo " - XSStrike: cd ~/XSStrike && python3 xsstrike.py"
echo " - Sherlock: cd ~/sherlock && python3 sherlock.py username"
