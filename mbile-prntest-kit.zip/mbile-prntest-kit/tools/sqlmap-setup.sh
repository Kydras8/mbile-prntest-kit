#!/data/data/com.termux/files/usr/bin/bash

echo "[+] Installing SQLMap for SQL Injection testing..."

pkg install git python -y

cd ~
git clone --depth 1 https://github.com/sqlmapproject/sqlmap.git

echo "[+] SQLMap installed in ~/sqlmap/"
echo "[+] Usage example:"
echo "python ~/sqlmap/sqlmap.py -u http://target.com/vuln.php?id=1 --dbs"
